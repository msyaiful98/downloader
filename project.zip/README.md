# Unduh

Aplikasi Android pribadi untuk mengunduh video/foto/audio dari link publik
(Instagram, TikTok, Facebook, X, Reddit, YouTube, dan situs lain yang didukung yt-dlp).
Tanpa iklan, tanpa tracker, tanpa login. Hanya untuk pemakaian pribadi.

## Cara build dari HP (sama seperti Lock)

1. Upload isi project ini ke repo GitHub (folder `.github/workflows` harus ikut).
2. Buka tab **Actions**, jalankan workflow **Build APK** (atau otomatis saat push).
3. Setelah hijau, buka run-nya, unduh artifact **Unduh-debug-apk**, ekstrak zip-nya.
4. Install `app-debug.apk` (aktifkan "izinkan sumber tidak dikenal").

Kalau build gagal, kirim potongan log yang ada tulisan `error:` atau `FAILED` saja.

## Cara pakai

- **Dari Instagram:** buka postingan/Reel, tap Share, pilih Unduh. Langsung terunduh.
- **Manual:** salin link, buka Unduh, tekan Tempel lalu Download.
- Hasil masuk ke galeri (folder `Unduh` di Movies/Pictures/Music). Riwayat ada di bawah layar.
- Centang "Audio saja" untuk mengambil suaranya saja (m4a).

## Catatan

- Pertama kali dibuka, mesin unduh perlu disiapkan beberapa detik.
- Kalau mendadak gagal terus, tekan **Perbarui mesin unduh**. Situs seperti Instagram
  sering mengubah sistemnya, dan pembaruan mesin biasanya cukup memperbaikinya.
- Konten private, berDRM (Netflix, Spotify, dll), atau yang wajib login tidak didukung.
- APK hanya berisi arsitektur arm64-v8a (HP/tablet modern).
- Tidak untuk diunggah ke Play Store.
