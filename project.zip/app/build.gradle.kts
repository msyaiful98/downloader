plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "id.syaiful.unduh"
    compileSdk = 34

    defaultConfig {
        applicationId = "id.syaiful.unduh"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"

        // Hanya arm64 (HP dan tablet modern) supaya APK tidak terlalu besar.
        ndk {
            abiFilters += listOf("arm64-v8a")
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    // Wajib untuk youtubedl-android: library native harus diekstrak ke disk.
    packaging {
        jniLibs {
            useLegacyPackaging = true
        }
    }
}

dependencies {
    implementation("io.github.junkfood02.youtubedl-android:library:0.17.4")
}
