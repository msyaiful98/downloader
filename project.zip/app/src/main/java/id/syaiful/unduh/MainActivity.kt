package id.syaiful.unduh

import android.Manifest
import android.app.Activity
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import java.io.File
import java.net.URL
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

class MainActivity : Activity() {

    // Satu antrean kerja: init mesin dulu, lalu unduhan berjalan berurutan.
    private val worker = Executors.newSingleThreadExecutor()

    private lateinit var linkInput: EditText
    private lateinit var audioOnly: CheckBox
    private lateinit var downloadButton: Button
    private lateinit var statusText: TextView
    private lateinit var progressBar: ProgressBar
    private lateinit var previewImage: ImageView
    private lateinit var previewTitle: TextView
    private lateinit var historyBox: LinearLayout

    private var busy = false

    private val dark: Boolean
        get() = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
            Configuration.UI_MODE_NIGHT_YES

    private val bgColor get() = if (dark) Color.parseColor("#121212") else Color.parseColor("#F6F7F9")
    private val cardColor get() = if (dark) Color.parseColor("#1E1E1E") else Color.WHITE
    private val textColor get() = if (dark) Color.parseColor("#EDEDED") else Color.parseColor("#1B1B1B")
    private val subColor get() = if (dark) Color.parseColor("#9E9E9E") else Color.parseColor("#6B6B6B")
    private val accent = Color.parseColor("#1E88E5")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        requestLegacyStoragePermission()

        if (!engineReady) {
            statusText.text = "Menyiapkan mesin unduh (sekali saja, beberapa detik)…"
            worker.execute {
                try {
                    YoutubeDL.getInstance().init(applicationContext)
                    engineReady = true
                    runOnUiThread { statusText.text = "Siap. Tempel link lalu tekan Download." }
                } catch (e: Exception) {
                    runOnUiThread { statusText.text = "Mesin gagal disiapkan: ${shortError(e)}" }
                }
            }
        } else {
            statusText.text = "Siap. Tempel link lalu tekan Download."
        }

        refreshHistory()
        handleShare(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleShare(intent)
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        // Android 10+ hanya mengizinkan baca clipboard saat aplikasi sedang fokus.
        if (hasFocus && linkInput.text.isNullOrBlank()) {
            val link = clipboardLink()
            if (link != null) linkInput.setText(link)
        }
    }

    // ---------------------------------------------------------------- UI

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, radiusDp: Int = 14): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radiusDp).toFloat()
        }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(32), dp(20), dp(24))
        }

        root.addView(TextView(this).apply {
            text = "Unduh"
            textSize = 28f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(textColor)
        })
        root.addView(TextView(this).apply {
            text = "Tempel link, tekan Download, tersimpan ke galeri."
            textSize = 14f
            setTextColor(subColor)
            setPadding(0, dp(4), 0, dp(20))
        })

        // Kolom link + tombol Tempel
        val linkRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = rounded(cardColor)
            setPadding(dp(14), dp(4), dp(6), dp(4))
        }
        linkInput = EditText(this).apply {
            hint = "https://www.instagram.com/reel/…"
            setHintTextColor(subColor)
            setTextColor(textColor)
            textSize = 15f
            background = null
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            maxLines = 2
        }
        linkRow.addView(linkInput, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        linkRow.addView(Button(this).apply {
            text = "Tempel"
            isAllCaps = false
            setTextColor(accent)
            background = null
            setOnClickListener {
                val link = clipboardLink()
                if (link != null) linkInput.setText(link)
                else Toast.makeText(this@MainActivity, "Tidak ada link di clipboard", Toast.LENGTH_SHORT).show()
            }
        })
        root.addView(linkRow, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))

        audioOnly = CheckBox(this).apply {
            text = "Audio saja (m4a)"
            setTextColor(textColor)
            setPadding(0, dp(8), 0, dp(8))
        }
        root.addView(audioOnly)

        downloadButton = Button(this).apply {
            text = "Download"
            isAllCaps = false
            textSize = 17f
            setTextColor(Color.WHITE)
            background = rounded(accent, 28)
            setOnClickListener { startDownload() }
        }
        root.addView(downloadButton, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dp(56)))

        progressBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            visibility = View.GONE
        }
        root.addView(progressBar, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
            topMargin = dp(14)
        })

        statusText = TextView(this).apply {
            textSize = 14f
            setTextColor(subColor)
            setPadding(0, dp(10), 0, dp(6))
        }
        root.addView(statusText)

        // Pratinjau
        previewImage = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            visibility = View.GONE
            background = rounded(cardColor)
            clipToOutline = true
        }
        root.addView(previewImage, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dp(200)).apply { topMargin = dp(6) })
        previewTitle = TextView(this).apply {
            textSize = 15f
            setTextColor(textColor)
            maxLines = 2
            visibility = View.GONE
            setPadding(0, dp(8), 0, 0)
        }
        root.addView(previewTitle)

        // Riwayat
        root.addView(TextView(this).apply {
            text = "Riwayat"
            textSize = 16f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(textColor)
            setPadding(0, dp(24), 0, dp(8))
        })
        historyBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(historyBox)

        // Perbarui mesin
        root.addView(TextView(this).apply {
            text = "Perbarui mesin unduh"
            textSize = 14f
            setTextColor(accent)
            setPadding(0, dp(28), 0, dp(8))
            setOnClickListener { updateEngine() }
        })
        root.addView(TextView(this).apply {
            text = "Kalau tiba-tiba gagal terus, coba perbarui mesin dulu. Situs seperti Instagram sering mengubah sistemnya."
            textSize = 12f
            setTextColor(subColor)
        })

        val scroll = ScrollView(this).apply {
            setBackgroundColor(bgColor)
            isFillViewport = true
            addView(root)
        }
        setContentView(scroll)
    }

    // ------------------------------------------------------- Link & Share

    private fun extractUrl(text: String?): String? {
        if (text.isNullOrBlank()) return null
        return Regex("https?://\\S+").find(text)?.value?.trimEnd(')', ']', ',', '.', '"')
    }

    private fun clipboardLink(): String? {
        return try {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val text = cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(this)?.toString()
            extractUrl(text)
        } catch (e: Exception) {
            null
        }
    }

    private fun handleShare(i: Intent?) {
        if (i?.action != Intent.ACTION_SEND) return
        val url = extractUrl(i.getStringExtra(Intent.EXTRA_TEXT)) ?: return
        linkInput.setText(url)
        // Dibuka lewat Share: langsung unduh tanpa perlu menekan tombol.
        startDownload()
    }

    // ------------------------------------------------------------ Unduh

    private fun startDownload() {
        if (busy) return
        val url = extractUrl(linkInput.text?.toString())
        if (url == null) {
            Toast.makeText(this, "Tempel link yang valid dulu", Toast.LENGTH_SHORT).show()
            return
        }
        busy = true
        downloadButton.isEnabled = false
        downloadButton.alpha = 0.5f
        progressBar.progress = 0
        progressBar.isIndeterminate = true
        progressBar.visibility = View.VISIBLE
        previewImage.visibility = View.GONE
        previewTitle.visibility = View.GONE
        statusText.text = "Membaca link…"
        val audio = audioOnly.isChecked

        worker.execute {
            try {
                // Pratinjau (judul dan thumbnail). Kalau gagal, unduhan tetap dicoba.
                try {
                    val info = YoutubeDL.getInstance().getInfo(YoutubeDLRequest(url))
                    val title = info.title ?: ""
                    val thumb = info.thumbnail
                    runOnUiThread {
                        if (title.isNotBlank()) {
                            previewTitle.text = title
                            previewTitle.visibility = View.VISIBLE
                        }
                    }
                    if (!thumb.isNullOrBlank()) loadThumbnail(thumb)
                } catch (ignored: Exception) {
                }

                runOnUiThread { statusText.text = "Mengunduh…" }

                val dir = File(cacheDir, "dl")
                dir.deleteRecursively()
                dir.mkdirs()

                val request = YoutubeDLRequest(url)
                request.addOption("-o", dir.absolutePath + "/%(id)s.%(ext)s")
                request.addOption("--no-playlist")
                request.addOption("--socket-timeout", "30")
                if (audio) {
                    request.addOption("-f", "bestaudio[ext=m4a]/bestaudio")
                } else {
                    request.addOption("-f", "best[ext=mp4]/best")
                }

                YoutubeDL.getInstance().execute(request, null) { progress, _, _ ->
                    runOnUiThread {
                        if (progress >= 0f) {
                            progressBar.isIndeterminate = false
                            progressBar.progress = progress.toInt().coerceIn(0, 100)
                            statusText.text = "Mengunduh… ${progress.toInt().coerceIn(0, 100)}%"
                        }
                    }
                }

                val files = dir.listFiles()
                    ?.filter { it.isFile && !it.name.endsWith(".part") && !it.name.endsWith(".ytdl") }
                    ?: emptyList()
                if (files.isEmpty()) throw IllegalStateException("Tidak ada file yang berhasil diunduh")

                var savedCount = 0
                val label = previewTitle.text?.toString().orEmpty()
                for (f in files) {
                    val uri = saveToGallery(f)
                    if (uri != null) {
                        savedCount++
                        addHistory(if (label.isNotBlank()) label else f.name, uri.toString(), mimeOf(f.name))
                    }
                    f.delete()
                }
                if (savedCount == 0) throw IllegalStateException("Gagal menyimpan ke galeri")

                runOnUiThread {
                    statusText.text = "Tersimpan ke galeri ✔"
                    Toast.makeText(this, "Tersimpan ke galeri", Toast.LENGTH_SHORT).show()
                    refreshHistory()
                }
            } catch (e: Exception) {
                runOnUiThread { statusText.text = friendlyError(e) }
            } finally {
                runOnUiThread {
                    busy = false
                    downloadButton.isEnabled = true
                    downloadButton.alpha = 1f
                    progressBar.visibility = View.GONE
                }
            }
        }
    }

    private fun loadThumbnail(thumbUrl: String) {
        Thread {
            try {
                val conn = URL(thumbUrl).openConnection()
                conn.connectTimeout = 10000
                conn.readTimeout = 10000
                val bmp: Bitmap? = conn.getInputStream().use { BitmapFactory.decodeStream(it) }
                if (bmp != null) {
                    runOnUiThread {
                        previewImage.setImageBitmap(bmp)
                        previewImage.visibility = View.VISIBLE
                    }
                }
            } catch (ignored: Exception) {
            }
        }.start()
    }

    // ---------------------------------------------------- Simpan ke galeri

    private fun mimeOf(name: String): String =
        when (name.substringAfterLast('.', "").lowercase()) {
            "mp4", "m4v" -> "video/mp4"
            "webm" -> "video/webm"
            "mkv" -> "video/x-matroska"
            "mov" -> "video/quicktime"
            "m4a" -> "audio/mp4"
            "mp3" -> "audio/mpeg"
            "opus", "ogg" -> "audio/ogg"
            "jpg", "jpeg" -> "image/jpeg"
            "png" -> "image/png"
            "webp" -> "image/webp"
            else -> "application/octet-stream"
        }

    private fun saveToGallery(file: File): Uri? {
        val mime = mimeOf(file.name)
        val (collection, folder) = when {
            mime.startsWith("video/") -> MediaStore.Video.Media.EXTERNAL_CONTENT_URI to Environment.DIRECTORY_MOVIES
            mime.startsWith("audio/") -> MediaStore.Audio.Media.EXTERNAL_CONTENT_URI to Environment.DIRECTORY_MUSIC
            mime.startsWith("image/") -> MediaStore.Images.Media.EXTERNAL_CONTENT_URI to Environment.DIRECTORY_PICTURES
            else -> MediaStore.Files.getContentUri("external") to Environment.DIRECTORY_DOWNLOADS
        }

        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, file.name)
                put(MediaStore.MediaColumns.MIME_TYPE, mime)
                put(MediaStore.MediaColumns.RELATIVE_PATH, "$folder/Unduh")
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
            val uri = contentResolver.insert(collection, values) ?: return null
            contentResolver.openOutputStream(uri)?.use { out ->
                file.inputStream().use { it.copyTo(out) }
            } ?: return null
            val done = ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }
            contentResolver.update(uri, done, null, null)
            uri
        } else {
            val targetDir = File(Environment.getExternalStoragePublicDirectory(folder), "Unduh")
            targetDir.mkdirs()
            val target = File(targetDir, file.name)
            file.inputStream().use { input -> target.outputStream().use { input.copyTo(it) } }

            var result: Uri? = null
            val latch = CountDownLatch(1)
            MediaScannerConnection.scanFile(this, arrayOf(target.absolutePath), arrayOf(mime)) { _, uri ->
                result = uri
                latch.countDown()
            }
            latch.await(4, TimeUnit.SECONDS)
            result
        }
    }

    private fun requestLegacyStoragePermission() {
        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P &&
            checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE), 1)
        }
    }

    // ------------------------------------------------------------ Riwayat

    private val prefs get() = getSharedPreferences("unduh", Context.MODE_PRIVATE)

    @Synchronized
    private fun addHistory(title: String, uri: String, mime: String) {
        val clean = title.replace('\n', ' ').replace('\t', ' ')
        val line = listOf(clean, uri, mime).joinToString("\t")
        val old = prefs.getString("history", "").orEmpty().split('\n').filter { it.isNotBlank() }
        val updated = (listOf(line) + old).take(20)
        prefs.edit().putString("history", updated.joinToString("\n")).apply()
    }

    private fun refreshHistory() {
        historyBox.removeAllViews()
        val lines = prefs.getString("history", "").orEmpty().split('\n').filter { it.isNotBlank() }
        if (lines.isEmpty()) {
            historyBox.addView(TextView(this).apply {
                text = "Belum ada unduhan."
                textSize = 13f
                setTextColor(subColor)
            })
            return
        }
        for (line in lines) {
            val parts = line.split('\t')
            if (parts.size < 3) continue
            val (title, uri, mime) = parts
            historyBox.addView(TextView(this).apply {
                text = title
                textSize = 14f
                maxLines = 2
                setTextColor(textColor)
                background = rounded(cardColor, 10)
                setPadding(dp(14), dp(12), dp(14), dp(12))
                setOnClickListener { openFile(uri, mime) }
            }, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                bottomMargin = dp(8)
            })
        }
    }

    private fun openFile(uri: String, mime: String) {
        try {
            val i = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(Uri.parse(uri), mime)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(i)
        } catch (e: Exception) {
            Toast.makeText(this, "File tidak bisa dibuka (mungkin sudah dihapus)", Toast.LENGTH_SHORT).show()
        }
    }

    // ------------------------------------------------- Perbarui & error

    private fun updateEngine() {
        if (busy) return
        busy = true
        statusText.text = "Memperbarui mesin unduh…"
        progressBar.isIndeterminate = true
        progressBar.visibility = View.VISIBLE
        worker.execute {
            try {
                val status = YoutubeDL.getInstance().updateYoutubeDL(applicationContext)
                runOnUiThread { statusText.text = "Pembaruan selesai: ${status ?: "OK"}" }
            } catch (e: Exception) {
                runOnUiThread { statusText.text = "Gagal memperbarui: ${shortError(e)}" }
            } finally {
                runOnUiThread {
                    busy = false
                    progressBar.visibility = View.GONE
                }
            }
        }
    }

    private fun shortError(e: Throwable): String {
        val msg = e.message ?: e.javaClass.simpleName
        val line = msg.lines().lastOrNull { it.isNotBlank() } ?: msg
        return if (line.length > 220) line.take(220) + "…" else line
    }

    private fun friendlyError(e: Throwable): String {
        val raw = shortError(e)
        val low = raw.lowercase()
        return when {
            "login" in low || "cookies" in low || "rate-limit" in low || "not available" in low ->
                "Instagram meminta login atau membatasi permintaan. Coba lagi nanti, atau perbarui mesin. Detail: $raw"
            "unable to resolve host" in low || "timed out" in low || "network" in low ->
                "Koneksi internet bermasalah. Cek jaringan lalu coba lagi."
            "unsupported url" in low ->
                "Link ini tidak didukung."
            else -> "Gagal: $raw"
        }
    }

    companion object {
        @Volatile
        private var engineReady = false
    }
}
